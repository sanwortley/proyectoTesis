import pool from '../db.js';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { registrarLogIngreso } from '../utils/logIngreso.js';

export const login = async (req, res) => {
  const { email, password } = req.body;
  const ip = req.ip;
  const userAgent = req.headers['user-agent'];

  try {
    const result = await pool.query('SELECT * FROM jugador WHERE email = $1', [email]);
    const user = result.rows[0];

    if (!user) {
      await registrarLogIngreso({ jugadorId: null, ip, userAgent, exitoso: false, motivo: 'Usuario no encontrado' });
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      await registrarLogIngreso({ jugadorId: user.id, ip, userAgent, exitoso: false, motivo: 'Contraseña incorrecta' });
      return res.status(401).json({ message: 'Contraseña incorrecta' });
    }

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '6h' });

    await registrarLogIngreso({ jugadorId: user.id, ip, userAgent, exitoso: true, motivo: 'Login exitoso' });

    res.json({ token, jugador: { id: user.id, nombre: user.nombre, email: user.email } });

  } catch (err) {
    console.error('Error en login:', err);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
};
