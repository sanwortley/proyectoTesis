import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import routes from './routes/index.js';
import routesLogs from './routes/auditoria.js'

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api', routes);
app.use('/api/auditoria', routesLogs);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
  console.log('[ROUTES] auditoria montada en /api/auditoria');

});
